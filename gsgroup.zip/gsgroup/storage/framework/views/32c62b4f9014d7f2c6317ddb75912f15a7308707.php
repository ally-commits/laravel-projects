<?php echo e($slot); ?>

<?php /**PATH /root/LARAVEL/gsgroup/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
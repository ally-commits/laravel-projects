<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.nav-d', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container" style="margin-top: 60px;">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </div> 

                <h5>Jobs Applications</h5>
                <div class="row ">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-4 card p-5 m-5 shadow-lg">   
                            <p><b>Job Type:</b> <?php echo e($val->job_type); ?></p>
                            <p><b>Experience:</b> <?php echo e($val->experience); ?></p>
                            <p><b>Current Working Location:</b> <?php echo e($val->working_location); ?></p>
                            <div style="width: 100%; display: flex;justify-content: space-between;">
                                <a style="text-decoration: none; width: 31%; height: 100%;" class="btn btn-primary p-1 shadow-sm" href="<?php echo e($val->resume); ?>">
                                    Resume File.
                                </a>
                                <a style="text-decoration: none; width: 31%; height: 100%;" class="btn btn-primary p-1 shadow-sm" href="<?php echo e($val->passport_image); ?>">
                                    Passport Image
                                </a>
                                <a style="text-decoration: none; width: 31%; height: 100%;" class="btn btn-primary p-1 shadow-sm" href="<?php echo e($val->education_certificate); ?>">
                                    Education Certifictae
                                </a>
                            </div>
                            <p style="font-style: italic;"><b>Message:</b> <?php echo e($val->description); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <h5>Events Registered</h5>
                <div class="row ">
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-4 card p-5 m-5 shadow-lg">   
                            <p><b>Kind of Event:</b> <?php echo e($val->event_kind); ?></p>
                            <p><b>Location:</b> <?php echo e($val->location); ?></p>
                            <p><b>Location(Indoor/Outdoor):</b> <?php echo e($val->door); ?></p>
                            <p><b>Date:</b> <?php echo e($val->date); ?></p>
                            <p><b>(Day/Night):</b> <?php echo e($val->day_night); ?></p>
                            <p><b>Crowd:</b> <?php echo e($val->crowd); ?></p>
                            
                            <p style="font-style: italic;"><b>Message:</b> <?php echo e($val->description); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/LARAVEL/gsgroup/resources/views/user/user-dashboard.blade.php ENDPATH**/ ?>
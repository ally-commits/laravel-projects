<?php $__env->startSection('content'); ?> 
    <?php echo $__env->make('includes.admin-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div style="margin-top: 60px; display: flex;justify-content: center;height: 80vh;width: 100%; align-items: center;">
        <button class="m-2 p-2 btn btn-success">
            <a class="text-white" href="/admin/job-r">View Job Registration</a>
        </button>
        <button class="m-2 p-2 btn btn-primary">
            <a class="text-white" href="/admin/event-r" >View Event Registration</a>
        </button>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/LARAVEL/gsgroup/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>
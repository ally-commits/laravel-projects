<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.nav-d', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container" style="margin-top: 60px;">
    <div class="row justify-content-center">
        <div class="col-sm-8 card shadow-lg">
            <form method="POST" action="/job-registration" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <h3 class="text-center mt-5">Job Registration</h3>
                <div class="form-group">
                    <label>Job Function</label>
                    <select name="job_type" class="form-control <?php if ($errors->has('job_type')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('job_type'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('job_type')); ?>">
                        <option value="Accounting">Accounting</option>
                        <option value="Marketing">Marketing</option>
                        <option value="Sales">Sales</option>
                        <option value="Engineering">Engineering</option>
                        <option value="Electrical">Electrical</option>
                    </select>
                    <?php if ($errors->has('job_type')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('job_type'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                    <label for="">Experience Month/Year</label>
                    <input type="text" name="experience" class="form-control <?php if ($errors->has('experience')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('experience'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('experience')); ?>">
                    <?php if ($errors->has('experience')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('experience'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                    <label for="">Current working location</label>
                    <input type="location" name="working_location" class="form-control <?php if ($errors->has('working_location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('working_location'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('working_location')); ?>">
                    <?php if ($errors->has('working_location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('working_location'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                    <label>Upload Resume</label>
                    <input type="file" class="form-control <?php if ($errors->has('resume')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('resume'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="resume" value="<?php echo e(old('resume')); ?>">
                    <?php if ($errors->has('resume')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('resume'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                    <label>Upload Passport Image</label>
                    <input type="file" class="form-control <?php if ($errors->has('passport_image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('passport_image'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="passport_image" value="<?php echo e(old('passport_image')); ?>">
                    <?php if ($errors->has('passport_image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('passport_image'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                    <label>Upload Highest Education Certificate</label>
                    <input type="file" class="form-control <?php if ($errors->has('education_certificate')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('education_certificate'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="education_certificate" value="<?php echo e(old('education_certificate')); ?>">
                    <?php if ($errors->has('education_certificate')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('education_certificate'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group <?php if ($errors->has('desscription')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('desscription'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                    <label>Enter Your Message</label>
                    <textarea rows="4"name="description" placeholder="Enter your Name" value="<?php echo e(old('description')); ?>"class="form-control <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                    
                    </textarea>
                    <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                    <input class="btn btn-success" type="submit" value="submit" name="Register">
                </div>
            </form>  
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/LARAVEL/gsgroup/resources/views/user/jobRegistration.blade.php ENDPATH**/ ?>
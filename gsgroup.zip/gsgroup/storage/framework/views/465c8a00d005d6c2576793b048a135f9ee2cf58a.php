<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.nav-d', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container" style="margin-top: 60px;">
    <div class="row justify-content-center">
        <div class="col-sm-8 card shadow-lg">
            <form method="POST" action="/event-registration" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <h3 class="text-center mt-5">Event Registration</h3>
                
                <div class="form-group">
                    <label for="">Kind of Event</label>
                    <input type="text" name="event_kind" class="form-control <?php if ($errors->has('event_kind')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('event_kind'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('event_kind')); ?>">
                    <?php if ($errors->has('event_kind')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('event_kind'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <label for="">Location</label>
                    <input type="text" name="location" class="form-control <?php if ($errors->has('location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('location'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('location')); ?>">
                    <?php if ($errors->has('location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('location'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <label>(Indoor /Outdoor)</label>
                    <select name="door" class="form-control <?php if ($errors->has('door')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('door'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('door')); ?>">
                        <option value="Outdoor">Outdoor</option>
                        <option value="Indoor">Indoor</option> 
                    </select>
                    <?php if ($errors->has('door')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('door'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                    <label for="">Enter Date</label>
                    <input type="date" name="date" class="form-control <?php if ($errors->has('date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('date')); ?>">
                    <?php if ($errors->has('date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <label>(Day /Night)</label>
                    <select name="day_night" class="form-control <?php if ($errors->has('day_night')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('day_night'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('day_night')); ?>">
                        <option value="Day">Day</option>
                        <option value="Night">Night</option> 
                    </select>
                    <?php if ($errors->has('day_night')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('day_night'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="">Crowd: </label>
                    <input type="number" name="crowd" class="form-control <?php if ($errors->has('crowd')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('crowd'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('crowd')); ?>">
                    <?php if ($errors->has('crowd')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('crowd'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                

                <div class="form-group <?php if ($errors->has('desscription')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('desscription'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                    <label>Enter Your Message</label>
                    <textarea rows="4"name="description" placeholder="Enter your Name" value="<?php echo e(old('description')); ?>"class="form-control <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                    
                    </textarea>
                    <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                    <input class="btn btn-success" type="submit" value="submit" name="Register">
                </div>
            </form>  
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/LARAVEL/gsgroup/resources/views/user/eventRegistration.blade.php ENDPATH**/ ?>
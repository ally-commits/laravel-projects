<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Gs Group</title>
        <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>" />
    </head>
    <body>
        <div style="width: 100%;height: 100vh;">
            <?php echo $__env->make('includes.nav-d', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <section class="section">
                <div class="container">
                <div class="row">
                    <form class="col-lg-8 mx-auto p-6 bg-gray rounded" action="/job-register" method="POST"  >
                    <?php echo e(csrf_field()); ?>

                    <div class="alert alert-success d-on-success">We received your message and will contact you back soon.</div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label style="font-size: 14px; text-indent: 10px;">Enter Your Name</label>
                            <input class="form-control form-control" type="text" name="name" placeholder="Your Name">
                        </div>

                        <div class="form-group col-md-6">
                        <label style="font-size: 14px; text-indent: 10px;">Enter Your Email</label>
                            <input class="form-control form-control" type="email" name="email" placeholder="Your Email Address">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label style="font-size: 14px; text-indent: 10px;">Enter Your Phone Number</label>
                            <input class="form-control form-control" type="text" name="phone" placeholder="Your Phone Number">
                        </div>
                        <div class="form-group col-md-6">
                            <label style="font-size: 14px; text-indent: 10px;">Enter Your Address</label>
                            <input class="form-control form-control" type="text" name="address" placeholder="Your address">
                        </div>
                    </div>
                    <div class="form-group">
                        <label style="font-size: 14px; text-indent: 10px;">Enter Your Job Qualification</label>
                        <textarea class="form-control form-control" rows="4" placeholder="Your Job Qualification" name="message"></textarea>
                    </div>

                    <div class="text-center">
                        <button class="btn btn-lg btn-primary" type="submit">Submit Inquiry</button>
                    </div>
                    </form>
                </div>

                </div>
            </section>
        </div>
        <!-- <script src="<?php echo e(asset('/js/script.js')); ?>"></script> -->
    </body>
</html>
<?php /**PATH /root/LARAVEL/gsgroup/resources/views/register.blade.php ENDPATH**/ ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <link rel="stylesheet" href="<?php echo e(asset('css/parallax-card.css')); ?>">
    <script src="<?php echo e(asset('js/parallax-card.js')); ?>"></script>
    <title>Document</title>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
<?php echo $__env->make('includes.onesignaljs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
<?php /**PATH /home/mrdebugger/projects/composite/resources/views/layout/front.blade.php ENDPATH**/ ?>
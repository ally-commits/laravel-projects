<section class="main">


    <div class="wrap wrap--1">
        <a href="https://google.com">
            <div class="container container--1">
                <p>BREAK IT TO WIN IT</p><br>
            </div>
        </a>
    </div>

    <div class="wrap wrap--2">
        <div class="container container--2">
            <p>02. Reverse</p>
        </div>
    </div>

    <div class="wrap wrap--3">
        <div class="container container--3">
            <p>03. Normal</p>
        </div>
    </div>

    <div class="wrap wrap--1">
        <div class="container container--1">
            <p>01. Normal</p>
        </div>
    </div>

    <div class="wrap wrap--2">
        <div class="container container--2">
            <p>02. Reverse</p>
        </div>
    </div>

    <div class="wrap wrap--3">
        <div class="container container--3">
            <p>03. Normal</p>
        </div>
    </div>
    <div class="wrap wrap--2">
        <div class="container container--2">
            <p>02. Reverse</p>
        </div>
    </div>

    <div class="wrap wrap--3">
        <div class="container container--3">
            <p>03. Normal</p>
        </div>
    </div>
    <div class="wrap wrap--2">
        <div class="container container--2">
            <p>02. Reverse</p>
        </div>
    </div>

    <div class="wrap wrap--3">
        <div class="container container--3">
            <p>03. Normal</p>
        </div>
    </div>
    <div class="wrap wrap--2">
        <div class="container container--2">
            <p>02. Reverse</p>
        </div>
    </div>

    <div class="wrap wrap--3">
        <div class="container container--3">
            <p>03. Normal</p>
        </div>
    </div>
    <div class="wrap wrap--2">
        <div class="container container--2">
            <p>02. Reverse</p>
        </div>
    </div>


</section>
<?php /**PATH /home/mrdebugger/projects/composite/resources/views/includes/events.blade.php ENDPATH**/ ?>
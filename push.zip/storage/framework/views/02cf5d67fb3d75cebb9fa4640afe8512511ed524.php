<?php $__env->startSection('content'); ?>
    <h1>EVENTS</h1>
    <?php echo $__env->make('includes.events', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mrdebugger/projects/composite/resources/views/pages/home.blade.php ENDPATH**/ ?>
<script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
<script>
    var OneSignal = window.OneSignal || [];
    OneSignal.push(function() {
        OneSignal.init({
            appId: "79667021-2655-4195-b56b-867a7895e7ac",
        });
    });
</script>
<?php /**PATH /home/mrdebugger/projects/composite/resources/views/includes/onesignaljs.blade.php ENDPATH**/ ?>
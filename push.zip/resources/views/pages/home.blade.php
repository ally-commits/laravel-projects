@extends('layout.front')

@section('content')
    <h1>EVENTS</h1>
    @include('includes.events')
@stop
